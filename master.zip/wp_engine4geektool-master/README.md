# wp_engine4geektool
repeating youtube video for geektool to realize wallpaper engine on mac

## How to use
1. setting geektool. (please refer to http://qiita.com/natmark/items/43f151ae663057a1883e)
2. clone this repos.
3. set vid in video.js
4. set local folder's path at geektool's property url
```
var vid = 'SlRfwbD2riE'; //please set youtube video's id that you want to play
```
